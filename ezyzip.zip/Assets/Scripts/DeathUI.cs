﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class DeathUI : MonoBehaviour
{
    [SerializeField] private Text survivalTime;
  
    [SerializeField] private TimeDisplay time;
    public float timeTaken;
    public bool timerActive = true;
    // Update is called once per frame





    void Start()
    {
    }
    void Update()
    {
        survivalTime.text = time.FormatTime();

        }
    }


