﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Rendering;

public class PlayerWeaponController : MonoBehaviour
{
    private Dictionary<string, Transform> weaponsDict;
    private List<Transform> weaponsList;
    public Transform EquippedWeapon { get; private set; }

    public Button PistolB;
    public Button KnifeB;
    public Button RifelB;
    public Button ShotgunB;

    void Awake()
    {
        Transform[] weapons = GetComponentsInChildren<Transform>();
        weaponsList = new List<Transform>();
        weaponsDict = new Dictionary<string, Transform>();


        for (int i = 1; i < weapons.Length; i++)
        {
           
            if (weapons[i].parent == transform)
            {
                weaponsList.Add(weapons[i]);
            }
        }

        foreach (Transform weapon in weaponsList)
        {
            weaponsDict.Add(weapon.name, weapon);
        }
        EquippedWeapon = weaponsDict["Knife"];
    }

    void Update()
    {
        Firearm firearm = EquippedWeapon.GetComponent<Firearm>();
        Knife knife = EquippedWeapon.GetComponent<Knife>();
        if ( (firearm != null && firearm.Reloading) || (knife != null && knife.Attacking) )
        {
            return;
        }

        /* if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            EquippedWeapon = weaponsDict["Knife"];
        }
        else if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            EquippedWeapon = weaponsDict["Pistol"];
        }
       else if (Input.GetKeyDown(KeyCode.Alpha3))
       {
           EquippedWeapon = weaponsDict["Rifle"];
       }
       else if (Input.GetKeyDown(KeyCode.Alpha4))
       {
           EquippedWeapon = weaponsDict["Shotgun"];
       }*/


        UpdateEquippedWeaponInScene();
   }

   void UpdateEquippedWeaponInScene()
   {
       foreach (Transform weapon in weaponsList)
       {
           if (weapon == EquippedWeapon)
           {
               weapon.gameObject.SetActive(true);
           }
           else
           {
               weapon.gameObject.SetActive(false);
           }
       }
   }

   public Weapon GetWeapon(string name)
   {
       return weaponsDict[name].GetComponent<Weapon>();
   }



   void Start()
   {
       Button pbtn = PistolB.GetComponent<Button>();
       pbtn.onClick.AddListener(pistolB);

       Button kbtn = KnifeB.GetComponent<Button>();
       kbtn.onClick.AddListener(knifeB);

       Button rbtn = RifelB.GetComponent<Button>();
       rbtn.onClick.AddListener(rifelB);

       Button sbtn = ShotgunB.GetComponent<Button>();
       sbtn.onClick.AddListener(shotgunB);
   }

   void pistolB()
   {
       EquippedWeapon = weaponsDict["Pistol"];
       Debug.Log("You have clicked the Pistol button!");
   }

   void knifeB()
   {
       EquippedWeapon = weaponsDict["Knife"];
       Debug.Log("You have clicked the Knife button!");
   }

   void rifelB()
   {
       EquippedWeapon = weaponsDict["Rifle"];
       Debug.Log("You have clicked the Rifle button!");
   }

   void shotgunB()
   {
       EquippedWeapon = weaponsDict["Shotgun"];
       Debug.Log("You have clicked the Shotgun button!");
   }




    }
