﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemCollector : MonoBehaviour
{
    [SerializeField] AudioManager aud;
    public string CollectedItemInfo { get; private set; }

    void OnTriggerEnter2D(Collider2D col)
    {
        SupplyBox box = null;
        SupplyBox1 box1 = null;
        SupplyBox2 box2 = null;

        box = col.GetComponent<SupplyBox>();
        box1 = col.GetComponent<SupplyBox1>();
        //box2 = col.GetComponent<SupplyBox2>();

        if (box != null)
        {
            CollectedItemInfo = box.SupplyBoxItem.UseItem();
            Debug.Log("data: " + CollectedItemInfo);
            box.SupplyBoxItem.PlaySoundEffect(aud);
            Destroy(box.gameObject);
        }



        if (box1 != null)
        { 
            CollectedItemInfo = box1.SupplyBoxItem.UseItem();
            box1.SupplyBoxItem.PlaySoundEffect(aud);
            Destroy(box1.gameObject);
        }


        
       /* if (box2 != null)
        {
            CollectedItemInfo = box2.SupplyBoxItem.UseItem();
            box2.SupplyBoxItem.PlaySoundEffect(aud);
            Destroy(box2.gameObject);
        }*/
    }
   
}
