﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Node1
{
    public bool walkable;
    public Vector2 worldPosition;
    public Node1 parent;
    public float f, g, h;

    public Node1(Vector2 worldPosition, bool walkable = true)
    {
        this.worldPosition = worldPosition;
        this.walkable = walkable;
        g = int.MaxValue;
        f = g + h;
    }
}
