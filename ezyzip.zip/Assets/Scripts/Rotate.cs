using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate : MonoBehaviour
{
    public Joystick joystick;
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed = 30f;
    private float joypos;
    public GameObject player;

    // Start is called before the first frame update
    void playerRotate()
    {
        float horizontal = joystick.Horizontal;
        float vertical = joystick.Vertical;
        
        Debug.Log("h" + horizontal);
        //rb.MoveRotation(rb.rotation + speed * Time.fixedDeltaTime);
        joypos = Mathf.Atan2(joystick.Horizontal, joystick.Vertical) * Mathf.Rad2Deg;
        //player.transform.eulerAngles = new Vector3(0, 0, horizontal *180);
        player.transform.eulerAngles = new Vector3(0,0, Mathf.Atan2(joystick.Vertical, joystick.Horizontal) * 180 / Mathf.PI);
    }

    // Update is called once per frame
    void Update() 
    {
        playerRotate();
    }
}
